# Firebase Setup Instructions

## 1. Create Firebase Project
1. Go to https://console.firebase.google.com/
2. Click "Add project"
3. Name: KsanniApp
4. Enable Google Analytics (optional)

## 2. Add iOS App
1. Click "Add app" → iOS
2. Bundle ID: com.iceveflausnir.ksanniapp
3. App nickname: KsanniApp iOS
4. Download GoogleService-Info.plist

## 3. Configure Services
Enable these services in Firebase Console:
- ✅ Authentication (Google Sign-In)
- ✅ Firestore Database
- ✅ Cloud Storage
- ✅ Analytics (optional)

## 4. Add to Xcode
1. Drag GoogleService-Info.plist into Xcode project
2. Make sure "Add to target" is checked
3. Verify file appears in project navigator

## 5. Test
Build and run app - Firebase should initialize without errors.
