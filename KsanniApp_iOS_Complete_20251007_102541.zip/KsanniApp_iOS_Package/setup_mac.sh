#!/bin/bash
# Mac Setup Script for KsanniApp iOS
echo "🍎 Setting up KsanniApp on macOS..."

# Check if Xcode is installed
if ! command -v xcodebuild &> /dev/null; then
    echo "❌ Xcode not found. Please install Xcode from the Mac App Store."
    exit 1
fi

# Check if CocoaPods is installed
if ! command -v pod &> /dev/null; then
    echo "📦 Installing CocoaPods..."
    sudo gem install cocoapods
fi

# Navigate to project directory
cd iosApp

# Install dependencies
echo "📦 Installing iOS dependencies..."
pod install

# Create Xcode project if needed
echo "🔨 Creating Xcode project..."
# The project structure is ready, just need to open .xcworkspace

echo ""
echo "✅ Setup complete!"
echo ""
echo "🎯 Next steps:"
echo "1. Add GoogleService-Info.plist from Firebase Console"
echo "2. Open KsanniApp.xcworkspace in Xcode"
echo "3. Build and run (⌘+R)"
echo ""
echo "📚 Read README_iOS.md for detailed setup instructions"
echo ""

# Open in Xcode
if command -v open &> /dev/null; then
    echo "🚀 Opening in Xcode..."
    open KsanniApp.xcworkspace
fi
